# IAS 2 Inventories — Content rewrite method (standing, Ch1–Ch6)

**Owner:** Content implement (Grok / agents)  
**Reviewer:** Johnny Pang  
**Locked:** 2026-09-30 (Asia/Shanghai) — Johnny phase + format locks for teaching body  
**EY pack unlocked:** 2026-10-01 — Johnny OK to enrich IAS 2 HTML from EY International GAAP® 2026 Ch23 (short paraphrase + cite chips; no large verbatim)
**Official cite chip lock:** 2026-10-01 — Johnny: `[Standard] · para [ref]` e.g. `IAS 2 · para 3`, `IAS 2 · para 3(a)`, `IAS 2 · para B1`, `IAS 2 · para BC1`, `IAS 2 · para IN7`. **Not** `Official · §3` / `Official · IN…` / `Official · BC…`. Keep class `cite-official`. Cross-standard: `IAS 16 · para 8`, `IAS 23 · para 4(b)`; bare `IFRS 13` when no para.  
**EY cite chip label lock:** 2026-10-01 — Johnny: chips use **`EY IGAAP 2026`** (not `EY International GAAP 2026`); keep path e.g. `EY IGAAP 2026 · Ch23 · §2.3`. Full book name OK in prose/source paths.  
**Cite-tag typography lock:** 2026-10-01 — Johnny: all `.cite` / `.cite-house` = font **Calibri Light**, **not bold** (`font-weight: 300`; stack `"Calibri Light", Calibri, "Segoe UI", sans-serif`).  
**Cite chip placement lock (REFINED):** 2026-10-01 — Johnny: **split rule** (supersedes title/lead-only for everything). (1) **Illustration** `.box` / `.worked-strip` with `Illustration: N.M.k — …`: chips ONLY at end of title line; body prose only — no chips in/after body. (2) **Main teaching paras / list items** (non-Illustration): chips at the **back** of that para or bullet (end of the unit) — NOT on a fake bold lead-only line if that emptied the body. Non-Illustration callout boxes: chips at end of `box-body`. Keep EY = `EY IGAAP 2026`; cite CSS = Calibri Light / weight 300.  
**Applies to:** `draft-v1-linked/ch0N.html` teaching `<article>` bodies; per-chapter `IAS2-CH0N-CONTENT-NOTES.md`  
**Does not apply to:** Concept Map HTML/CSS / iframes / chrome / footer — **set Map aside this pass**; visuals only after Johnny OK  
**Map / index:** `index.html` is the Map page — **do not rewrite Map body / iframe**.

**Skills:**  
- Body / study-pack content → [IFRS teaching body](sand-workflow:ifrs-teaching-body)  
- Concept Maps / visuals only → [IFRS visual grammar](sand-workflow:ifrs-visual-grammar)

---

## Research essence (Johnny 2026-10-01)

**Consolidate first:** pull **all** Official examples/illustrations **and** all pack Big4 named examples / FAQ-with-body / worked plates into the chapter so the learner does **not** need separate PDFs for one standard. Detail-first; thin teaching is wrong this phase. Multi-firm (DTT + PwC + EY), not PwC FAQ-only. NOTES-only leftovers = gaps unless body missing, copyright FS-block, or Johnny deferred.

## Phase lock (Johnny 2026-09-30)

1. **Integrate Official IAS 2 + Big4 into one study pack first** (detail learning). Simplify later — do **not** thin the pack in this phase.
2. Concept Map may **start** the page, but **set Map aside** this pass: update **all chapter teaching bodies** first; **no iframe / visual / cache-bust edits**.
3. **Quote-heavy is OK now** — prefer Official `<q>` extracts + Big4 support over paraphrase.
4. **Decision strips / trees are OK** if **no invented facts** — every gate cites Official or Big4.
5. **Include ALL Official examples/illustrations + Big4 examples** that belong to the chapter topic; wrap each in a **line box** using existing `.box` / `.worked-strip` patterns (title e.g. `Illustration: N.M.k — …`; chips e.g. `IAS 2 · para 16`, `DTT A11 2022 · 3.2.3.3-1`, `PwC MOA 2020 · FAQ 25.22.1`). Reproduce tables / key figures faithfully with cites — **not invented numbers**. Do **not** leave examples “thin” or NOTES-only.
6. **Official IAS 2 has limited numbered IE series** (unlike IFRS 18). Still include every Official illustration that exists: §16 exclusion list examples, IN/BC LIFO narrative, harvest deemed-cost §20, any Illustrative Examples in the Official PDF. Cite chips as `IAS 2 · para …` / `IAS 2 · para IN…` / `IAS 2 · para BC…` (not `Official · §…`).

---

## Format rules (mandatory)

1. **Bold key points** — every teaching key idea wrapped in `<strong>…</strong>` (section lead sentences, bullet heads, matrix axis labels that carry the teaching point).
2. **Layers of bullet points** — nested `<ul>` / `<ol>` for **super detail** (not brief). Under each teaching set, expand with:
   - **Official** extract (para / IN / BC) in `<q>…</q>` + cite chip (`IAS 2 · para …`)
   - **Big4** extract (DTT A11; PwC MOA Ch25 / FAQ) in `<q>…</q>` or short firm paraphrase with cite chip
3. **Tables / matrices — not mandatory; use when multi-column helps**
   - Prefer a table when the content naturally has **more than 2 columns** (comparison, multi-axis, carve-out matrix, firm alignment next to Official).
   - Do **not** force every section into a table. Linear teaching (objective, pitfall, handoff) can stay nested bullets.
   - **Inside table cells**, nested `<ul>` / `<ol>` bullets are OK and **preferred** for detail.
4. **Big4 dedupe** — if several firms say the **same** thing, merge into **one** row/bullet with multiple cite chips (e.g. DTT · PwC). Keep distinct firm views in **separate** bullets/rows when they differ (label “DTT only” / “PwC only” as needed).
5. **Line-boxed examples** — for each chapter-relevant Official illustration and Big4 named example / FAQ-with-body (DTT, PwC, EY as packed — not PwC FAQ only):
   - Prefer `.worked-strip` (title + `.worked-strip-grid` of `.box` peers) **or** a single `.box` with `.box-title` / `.box-body` when one plate is enough.
   - **Title = `Illustration: N.M.k — [Teaching Title]`** — `N.M` = parent section (e.g. 3.2); `k` resets per section and increments for each example `.box` / `.worked-strip` in order (e.g. `Illustration: 3.2.1 — Access road / present location and condition`). Firm + FAQ/para ids go in **cite chips** only — never in the title string. Nested strip labels (`Facts` / `Principal`) are not numbered.
   - **List / bullet bold titles ≠ cite strings** — bold lead = scan landmark (who/what in Official wording). Chips alone carry `IAS 2 · para …` / firm. Never bold `Official §N`, `IAS 2 · para N`, or `Big4 / Firm` as the title; do not invent labels.
   - Faithful wording / figures from the source (EY: short paraphrase only). Cite chips: **Illustration** → on title only (not inside `box-body`); **teaching paras/lis** → at **end of the unit** (not fake bold-lead-only hoist).
6. **Decision strip** — optional Start → Gate → Output (or tree) for judgement paths; **every step cited**; remove invented entity patterns.
7. **Visuals** — do **not** rewrite Concept Map HTML/CSS / iframe `?v=` in a content pass. Body-only. Suggest visual adjustments in the chapter NOTES only; implement only after Johnny OK.
8. **Cite-chip sections (Official + EY + typography + placement locks)** — Official chips: `IAS 2 · para 9`, `IAS 2 · para 3(a)`, `IAS 2 · para IN7`, `IAS 2 · para BC1`, `IAS 2 · para 25 fn`. **Not** `Official · §9`. Cross-standard: `IAS 16 · para 8`, `IAS 23 · para 4(b)`; bare `IFRS 13` when no para. EY chips: **`EY IGAAP 2026 · Ch23 · …`** (not `International GAAP`). Other firm chips unchanged (`DTT A11 2022 · 3.2.3.3-1`, `PwC MOA 2020 · 25.22` / FAQ id). Keep colour classes. Include `fn` inside the tag when applicable. Typography: all chips Calibri Light, `font-weight: 300` (not bold). **Placement (split):** Illustration `.box` / `.worked-strip` → chips on title only, body prose only; main teaching paras/lis → chips at **end of unit** (undo bold-lead over-hoist); non-Illustration callouts → end of `box-body`.
9. **Anchors** — Preserve `#s-N-…` ids that Map / visual chips deep-link to (including `#s-3-ex-b`, `#s-3-ex-c`, `#s-4-ex-a`, `#s-4-ex-d`).
10. **Site labels** — **IAS 2 / IFRS** only (no HKAS dual code on UI). Official HKAS 2 text is treated as IAS 2 on site.

---

## Content rules (substance)

| Rule | Detail |
|------|--------|
| **Quote Official + Big4 (+ EY)** | Official PRIMARY: `inputs/hkas/hkas-2-inventories.pdf` (= IAS 2 on site; symlink under `inputs/ias-2/`). Firms in pack: **DTT** 2022 A11 Inventories; **PwC** MOA 2020 Ch25; **EY** International GAAP® 2026 Ch23 Inventories (`inputs/ey-international-gaap-2026/`). **No invented KPMG** (not in pack). EY: short paraphrases + cite chips only — **no large verbatim** blocks (copyright). |
| **Official quotes primary** | Prefer short `<q>` extracts + cite chips over free rewrite. Firms support / align; do not replace Official. |
| **No invented examples** | No entity fact patterns not in Official §§/IN/BC or firm materials. Teaching cues = firm quote + Official aim OK. Decision strips cite gates only. Preserve existing worked strips if they match Standard/Big4 arithmetic; upgrade titles/cites; replace invented-looking patterns. |
| **Examples complete** | Every Official illustration + **all pack firms’** named examples / FAQ-with-body (DTT, PwC, EY short boxes) that belong to the chapter appear as line boxes — not NOTES-only, not PwC-FAQ-only densify. Thin/missing FAQ body → NOTES gap, do not invent. EY = short paraphrase + cite chips, no large verbatim. |
| **Teaching spine** | Organising idea: lower of cost and NRV (§9); Cost∥NRV peers; LIFO banned (IN13/BC + §25 by omission). Ch2 Recognition stays **light**. Ch3 = cost build-up + formulas; Ch4 = subsequent / NRV / write-down / capped reversal. Keep Initial ≠ Subsequent. Do not renumber chapters. |
| **Anchors** | Preserve `#s-N-…` Map deep-links. |
| **Leave iframe / visuals alone** | No cache-bust or copy change in visuals unless Johnny OK’d a visual pass. |
| **Site labels** | IAS 2 / IFRS only (no HKAS dual codes on UI). |
| **Do not split for split’s sake** | Keep existing section grain unless teaching logic truly requires a split. |

---

## Per-chapter workflow

1. Inventory sources in NOTES `(a)` (paths under `inputs/hkas/`, `inputs/dtt-moa-2022-june21/`, `inputs/pwc-2020-moa/chapters/`, `inputs/ey-international-gaap-2026/`) — list Official §§/IN/BC illustrations + DTT/PwC pieces that belong to the chapter.
2. Gap prior body in NOTES `(b)` — missing quotes, thin examples, invented patterns, missing firm section chips, **and** missing named examples from every pack firm (not only PwC FAQ backlog).
3. Backup `ch0N.html` under `/workspace/ias2-content-extract/` with timestamp before edit.
4. Rewrite **body only** to format rules; keep chrome, Concept Map fieldset/iframe, key-terms (unless cite chips broken), footer-nav.
5. Record boxes added, matrices kept/added, left-outs, backup paths in NOTES `(c)–(e)`; open questions / honest gaps in `(f)`.
6. Fold any Johnny format steer into **this METHOD** and the **IFRS teaching body** skill (principle only — no chapter dump).

---

## Site chapter ↔ Official / firm map

| Site | Official | DTT 2022 A11 | PwC MOA 2020 Ch25 | EY IGAAP 2026 Ch23 |
|------|----------|--------------|------------------|---------------------|
| Ch1 Scope | §2–§8, §20 tip, IN6–IN9; BC6–BC8 | 2 Scope; pipeline fill 2.1-2; crypto 2.1-3; fulfilment 2.3 | 25.3–25.8; FAQ 25.8.1; spare parts FAQ 25.10.1 | §2.3 Scope / broker; §2.3.1 practical (emission, green certs, crypto) |
| Ch2 Recognition | §6, §8 (light); expense exits → Ch5 | pipeline / inventory definition cues | 25.9–25.14; FAQ 25.10.1; consignment FAQ 25.46.x | §2.3.1.H–I consignment / returns (light cues) |
| Ch3 Initial measurement | §10–27, §17–18, §20–22; IN13; BC9–BC20 | 3.2 cost; discounts/rebates; normal capacity OH; joint/by-product; retail; FIFO/WA | 25.15–25.33; FAQs 25.19.x, 25.21.1, 25.22.1, 25.25.x, 25.32.1 | §3.1 cost; §3.1.3.E forward contracts (IFRS 9 edge) |
| Ch4 Subsequent measurement | §9, §6–7, §28–33; IN15 | 3.3 NRV; post-period; firm contracts; materials; reversals; costs to sell | 25.34–25.41; FAQs 25.8.1, 25.36.1, 25.39.1, 25.40.1 | §3.3 NRV |
| Ch5 Derecognition | §34–35; IN14 | 3.4 Recognition as expense | 25.42–25.46; FAQ 25.42.1 | §5 Recognition in P&L |
| Ch6 Disclosure | §36–39; IN16–IN17 | 4.2 Disclosure | 25.47–25.51 | §6 Disclosure (+ crypto extras) |

---

## Ch1–Ch6 checklist (quick)

- [ ] Lead of each section + each major bullet head is **bold**
- [ ] Nested bullets under each set with **Official** + **Big4** extracts (quote-heavy OK)
- [ ] **All** chapter-relevant Official + pack Big4 named examples / FAQ-with-body in `.box` / `.worked-strip` (multi-firm; titles `Illustration: N.M.k — …`; cite chips hold firm/FAQ ids)
- [ ] Table/matrix only where **>2 columns** helps (not forced); nested `<ul>` OK inside cells
- [ ] Decision strips (if any) cite every gate; no invented entity facts
- [ ] Same Big4 points merged (multi cite chips); distinct firm views kept separate
- [ ] No invented examples; **no KPMG invent**; EY from pack = short paraphrase + cite chips (no large verbatim); box titles + list bold leads do not duplicate cite chips / § numbers
- [ ] Official cite chips = `IAS 2 · para …` (not `Official · §…`); EY chips = `EY IGAAP 2026 · …`; include `fn` when applicable; other firm chips keep house + section/FAQ id; cite CSS = Calibri Light / weight 300; **split placement** — Illustration chips on title only; teaching paras/lis chips at end of unit
- [ ] Anchors preserved; iframe/visuals/Concept Map untouched
- [ ] NOTES updated with box IDs added; visual suggestions (if any) in NOTES only
- [ ] Ch2 stays light; Ch3 ≠ Ch4 (Initial ≠ Subsequent); LIFO ban cites IN13/BC
