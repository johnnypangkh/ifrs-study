---
name: IFRS teaching body
description: >-
  Use when rewriting IFRS/IAS/CF chapter teaching HTML: consolidate ALL Official
  + pack Big4 examples/illustrations into one study pack (detail-first);
  numbered Illustration titles + cite chips — not Concept Maps.
---
# IFRS teaching body (content rewrite)

**When:** rewriting a chapter teaching `<article>` for an IFRS/IAS/CF study pack so learners study **one integrated place** instead of many PDFs. Concept Maps are a separate visual pass ([IFRS visual grammar](sand-workflow:ifrs-visual-grammar)).

## Research essence (Johnny — non-negotiable)

This project **first consolidates all detail** for one standard into the site pack so Johnny does **not** need to open Official + Big4 PDFs separately for the same topic.

- **Extract and place** every Official example / illustration / IE / IG / worked figure that belongs to the chapter.
- **Extract and place** every pack Big4 named example, FAQ-with-body, illustration, and worked numeric plate that belongs to the chapter — **across all firms in the pack**, not one FAQ series only.
- Prefer **faithful** figures/tables from the source over paraphrase; short paraphrase + cite is OK where copyright forbids large verbatim (esp. EY books).
- Leaving a pack example “NOTES-only” or “later densify” is a **gap**, not done — unless body is missing/thin in the extract, third-party FS reprint is blocked, or Johnny explicitly deferred.
- Thin teaching / skipping examples for brevity is **wrong** in this phase. Detail-first → simplify later.

**Phase:** Quote-heavy OK. Set Concept Map aside until bodies for that pack are updated (unless Johnny unlocks visuals).

## Product intent

- Professional **visual study book**, not a legal reprint — still pull **full** Official + pack Big4 detail (bold, bullets, matrices, line boxes).
- Concept Map = jump board; body = deep study / single research surface.
- Do **not** invent entity fact patterns. Decision strips OK only when every gate cites Official or pack Big4.

## Cite-tag formatting (Johnny lock 2026-10-01) — FULL

All cite chips use `<span class="cite cite-…">` (keep colour classes: `cite-official`, `cite-dtt`, `cite-pwc`, `cite-ey`, …). Firm/source **and** section/FAQ/para id live **inside the tag only**.

### A. Label formats

| Source | Locked chip text | Forbidden |
|--------|------------------|-----------|
| Official (IAS/IFRS pack) | `[Standard] · para [ref]` e.g. `IAS 2 · para 3`, `IAS 2 · para 3(a)`, `IAS 2 · para B1` / `BC1` / `IN7` | `Official · §3`, `Official · IN7`, `Official · BC1` |
| Cross-standard | `IAS 16 · para 8`, `IAS 23 · para 4(b)`; bare `IFRS 13` when no para | `Official · IAS 16 §8` |
| EY book | **`EY IGAAP 2026 · …`** e.g. `EY IGAAP 2026 · Ch23 · §2.3` | `EY International GAAP 2026 · …` |
| DTT / PwC / KPMG | keep pack forms: `DTT A11 2022 · …`, `PwC MOA 2020 · …` / FAQ id; KPMG only when packed | inventing a firm not in pack |

- Full EY book title (`International GAAP® 2026`) OK in METHOD / prose / source paths; **chips use IGAAP**.
- HTML pattern for house chips: `<span class="cite cite-ey"><span class="cite-house">EY</span> IGAAP 2026 · Ch23 · §2.3</span>` (same `cite-house` pattern for DTT/PwC).

### B. Typography (CSS)

- **All** `.cite` / `.cite-house`: font **Calibri Light**, **not bold**.
- CSS: `font-family: "Calibri Light", Calibri, "Segoe UI", sans-serif;` and `font-weight: 300` (never 700/800).
- Pack-wide via `assets/shared.css` + `assets/draft.css` (and `visuals/shared.css` twin if present).

### C. Placement — split rule (Johnny REFINED lock 2026-10-01)

**Supersedes** the prior “title / lead only for everything” rule. Two patterns:

#### C1. Illustration boxes — chips on title only

Applies to `.box` / `.worked-strip` whose title is `Illustration: N.M.k — …`.

| Where chips live | Body |
|------------------|------|
| On `box-title` / `worked-strip-title` **after** `Illustration: N.M.k — Title` | Prose only — **no** chips in `box-body`, nested fact/analysis boxes, or after last sentence |

```
Illustration: N.M.k — [Teaching Title]  <cite chips…>
```

- Reset `k` per parent section `N.M`.
- Title = teaching name only; firm/FAQ/para ids **only** in chips (no title↔chip text duplicate).
- Deduplicate title↔body: same cite on both → keep **title**; body-only → **move up** to title (do not delete sources).

#### C2. Main teaching paras / list items — chips at end of unit

Applies to **non-Illustration** teaching content: ordinary `<p>`, list `<li>`, and non-Illustration callout boxes.

| Pattern | Where chips live |
|---------|------------------|
| Teaching `<p>` or list `<li>` | At the **back** of that para or bullet (**end of the unit**), after the body prose |
| Bold lead inside the unit | Lead stays a **scan landmark** only — do **not** park chips immediately after `</strong>` when that empties the body or leaves a fake lead-only chip line |
| Non-Illustration `.box` (no `Illustration:` title) | Chips at **end of `box-body`** (not hoisted onto `box-title`) |
| Table cell / cite column | End of that cell’s teaching unit — OK |

**Do not** hoist chips onto a bold lead when the unit still has body text after the lead. **Do** keep Illustration title chips (C1) unchanged.

**List / bullet bold leads ≠ cite strings**

- Bold lead = **scan landmark** (who / what situation) in Official or pack-firm wording.
- Cite chips alone carry `IAS 2 · para …` / firm paths.
- **Never** bold `Official §N`, `IAS 2 · para N`, `Official IN…`, or `Big4 / Firm` as the title.
- Do not invent labels — lift short teaching titles from Official/standard wording only.

### D. Worked example (crypto plate)

```html
<div class="box" id="s-1-ex-crypto">
  <p class="box-title"><strong>Illustration: 1.1.2 — Cryptocurrencies held for ordinary-course sale</strong>
    <span class="cite cite-dtt">…</span>
    <span class="cite cite-official">IAS 2 · para 3</span>
    <span class="cite cite-official">IAS 2 · para 36–39</span>
    <span class="cite cite-ey"><span class="cite-house">EY</span> IGAAP 2026 · Ch23 · §2.3.1.F</span>
    <span class="cite cite-ey"><span class="cite-house">EY</span> IGAAP 2026 · Ch23 · §3.4.2</span>
  </p>
  <p class="box-body">…prose only — no cite chips…</p>
</div>
```

## Mandatory format (other)

1. **Bold** key teaching points (`<strong>`).
2. **Layered bullets** — Official extract + Big4 support under each set (super detail).
3. **Tables** — not mandatory; use when **>2 columns** help; nested lists OK inside cells.
4. **Big4 dedupe** — same point → one bullet/row + multi cite chips; distinct firm views stay separate.
5. **Cite chips** — follow **Cite-tag formatting** section above (labels + typography + **split placement** (Illustration title; teaching unit end)).
6. **Examples / illustrations (complete extract)** — inventory Official **and every pack firm**; wrap each in `.box` / `.worked-strip`. Prefer source tables/figures. Skip only: missing/thin body; blocked third-party FS reprint (NOTES); Johnny deferred.
7. **Decision strip** — optional; no invented facts.
8. **Visuals** — no Map/iframe/cache-bust in a content pass.
9. **Anchors** — preserve `#s-N-…`.
10. **Sources (pack-gated) + copyright** — Official primary; firms only if in pack `inputs/` / METHOD. Short paraphrase + cite OK; no large verbatim of copyrighted Big4/EY. Typical locks:
    - **IFRS 18:** KPMG FI; EY Closer look; DTT as IAS 1 bridge; no invented PwC.
    - **CF 2018:** DTT A2; PwC intro when present; no invented KPMG/EY CF unless packed.
    - **IAS 2:** Official HKAS 2 (=IAS 2 on site); DTT A11; PwC MOA Ch25; EY IGAAP 2026 Ch23 (book: International GAAP® 2026); no invented KPMG. Site labels: IAS 2 / IFRS only.

## Per-chapter workflow

1. **Full inventory** of Official illustrations + **all** pack Big4 named examples/FAQs/IEs for the chapter in `*-CH0N-CONTENT-NOTES.md`.
2. Gap prior body against that inventory (multi-firm — not PwC-only).
3. Backup; rewrite body only; number `Illustration: N.M.k — Title`; place cite chips per **split rule** (Illustration → title; teaching paras/lis → end of unit).
4. NOTES record every box + honest left-outs; fold format steers into pack METHOD **and** this skill (principle only).

## Done when

- [ ] One-site consolidate: chapter has Official + all pack Big4 examples/illustrations that belong — learner need not open those PDFs for that topic
- [ ] Quote-heavy Official + Big4 under teaching sets
- [ ] Titles = `Illustration: N.M.k — Teaching Title`; list bold leads = scan landmarks (not cite strings)
- [ ] Cite tags: Official = `IAS 2 · para …`; EY = `EY IGAAP 2026 · …`; CSS = Calibri Light / weight 300; **split placement** — Illustration chips on title only; main teaching paras/lis chips at **end of unit** (no fake bold-lead-only hoist)
- [ ] No invented examples; Map untouched; NOTES + METHOD updated if needed
