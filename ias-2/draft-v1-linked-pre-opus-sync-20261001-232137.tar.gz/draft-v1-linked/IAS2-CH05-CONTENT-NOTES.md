# IAS 2 Ch5 Derecognition — CONTENT NOTES

**Date:** 2026-09-30 (Asia/Shanghai)  
**Scope:** Teaching body of `ch05.html` (+ this notes)  
**Not touched:** Concept Map / iframe `?v=ias2-v3`, chrome, key-terms, footer  
**Standing method:** [`IAS2-CONTENT-REWRITE-METHOD.md`](IAS2-CONTENT-REWRITE-METHOD.md)

## (a) Source inventory
| ID | Source | Belong? |
|----|--------|---------|
| §34–35; IN14 | Official | Yes |
| DTT 3.4 Recognition as an expense | DTT | Yes |
| PwC 25.42–25.46; FAQ 25.42.1 | PwC | Yes |

## (b) Gaps before
Accurate but thin on Official quotes / firm FAQ presentation of reversals.

## (c) Examples this pass
| Box ID | What |
|--------|------|
| `#s-5-ex-rev` | PwC FAQ 25.42.1 reversal presentation (+ tax line) |
| Cross-links | Ch4 SKU write-down 10; capped reverse 20 |

## (d) Left out
Full consignment / reservation-of-title deep dive stays as control cue (Ch2) + PwC 25.46 pointer — not expanded into invented theatre. FAQ 25.46.2 reservation of title — title noted in pack; body not duplicated here beyond Ch2 consignment cue.

## (e) Backup
`/workspace/ias2-content-extract/ch05-before-content-rewrite-2026-09-30-224843+0800.html`

## (f) Honest gaps
- Official has no numbered IE for expense exits — quotes §34–35 directly.

## (g) Visual suggestions
Ensure §34 chip on expense-exit family (prior content review) when visual pass unlocked.


---
## Completeness 2026-10-01
- Reviewed: Official §34–35 `<q>` already present; FAQ 25.42.1 boxed. No body edit required this pass (Ch2 now holds FAQ 25.46.2).
- Map/iframe untouched. Backup snapshot: `ias2-content-extract/ch05-before-completeness-20261001-133909+0800.html` (unchanged content vs prior).

## KPMG Insights 2019/20 · 3.8 (2026-10-01)
- **In pack.** Enriched Illus 5.3.1 with Ex 17 disclosure-of-reversal quantitative peer.
- Still **no invent outside sources**.

## KPMG defer-unfreeze 2026-10-01
- **Ex17** `#s-5-ex-kpmg-rev17` Illus 5.3.2 — disclosure of reversals (100→80→sold 120→disclose 20) + cost-of-sales presentation view.
- Teaching bullet under 5.3; PwC FAQ Illus 5.3.1 kept (presentation/tax).
- Backup: `ias2-content-extract/ch05-before-ex151617-densify-*`
