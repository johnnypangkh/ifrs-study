# IAS 2 Ch6 Disclosure — CONTENT NOTES

**Date:** 2026-09-30 (Asia/Shanghai)  
**Scope:** Teaching body of `ch06.html` (+ this notes)  
**Not touched:** Concept Map / iframe `?v=ias2-v2`, chrome, key-terms, footer  
**Standing method:** [`IAS2-CONTENT-REWRITE-METHOD.md`](IAS2-CONTENT-REWRITE-METHOD.md)

## (a) Source inventory
| ID | Source | Belong? |
|----|--------|---------|
| §36–39; IN16–IN17 | Official | Yes |
| DTT 4.2 Disclosure (+ crypto disclosure tip from 2.1-3) | DTT | Yes |
| PwC 25.47–25.51 | PwC | Yes |

## (b) Gaps before
Accurate package teaching; missing Official quote chips with lettered §36 items and firm alignment.

## (c) Examples / matrices this pass
| Box ID | What |
|--------|------|
| §36 matrix table | Letter (a)–(h) → user need + cite |
| Nested bullets | Official §36–39 quotes + DTT/PwC support |

No separate numeric IE in Official for disclosure — none invented.

## (d) Left out
Measurement model teaching → Ch3–Ch4. No invented sample note face.

## (e) Backup
`/workspace/ias2-content-extract/ch06-before-content-rewrite-2026-09-30-224843+0800.html`

## (f) Honest gaps
- PwC Ch25 has no FAQ series dedicated solely to disclosure beyond narrative 25.47–25.51 — used those paragraphs; no invented FAQ answers.

## (g) Visual suggestions
None beyond keeping disclosure as lighter secondary on Map.


---
## Completeness 2026-10-01
- Added Official `<q>` for §36(c) FV-less-CTS carrying amount under `#s-6-3`.
- No PwC FAQ series for disclosure — none invented.
- Map/iframe untouched (`visuals/ch06-disclosure.html?v=ias2-v4`).
- Backup: `ias2-content-extract/ch06-before-completeness-20261001-133909+0800.html`
- EY candidates (NOTES only): EY Ch23 §6 disclosure + crypto extras (pp1720–1722).

## KPMG Insights 2019/20 · 3.8 (2026-10-01)
- **In pack.** KPMG chips on 6.4 write-down/reversal disclosure (Ex 17 / 3.8.400).
- No invented sample note face.

## KPMG defer-unfreeze 2026-10-01
- **Ex17** `#s-6-ex-kpmg-rev17` Illus 6.4.1 — disclosure Illus; §6.4 enriched with 3.8.400.70–90 + presentation cues.
- Backup: `ias2-content-extract/ch06-before-ex151617-densify-*`


---
## XREF gap-clear 2026-10-01 (BC22–BC23)
- §6.4 new teaching bullet: CoS / inventories-as-expense disclosure retained in IAS 2 (ED had proposed deletion relying on IAS 1). Chips `IAS 2 · para BC22–BC23`, para 36(d), para 38.
- Backup: `ias2-content-extract/ch06-before-xref-gap-clear-20261001-165729+0800.html`

## EY FS Practical unlock (2026-10-01)

| Anchor | Illus | EY locator | Teaching home |
|--------|-------|------------|---------------|
| `#s-6-ex-ey-stora` | **6.2.1** | Practical example 6-2 Stora Enso Oyj (2022) | §6.2 classifications + allowances |
| `#s-6-ex-ey-unilever` | **6.4.2** | Practical example 6-1 Unilever PLC (2022) | §6.4 disclosure pack (classes, provision roll-forward, write-downs) |

Personal-study unlock. Tables use source €m / EURm figures. EY Ch23 book pp 1720–1721.
